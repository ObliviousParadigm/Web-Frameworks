from django.contrib import admin
from .models import team

admin.site.register(team)