from django.urls import path
from central import views

app_name = 'central'

urlpatterns = [

]
