from django.contrib import admin
from central.models import Hackathon, Team, Challenge

# Register your models here.

admin.site.register(Hackathon)
admin.site.register(Challenge)
admin.site.register(Team)
